//
//  ViewSavedController.h
//  VAS002
//
//  Created by Melvin Manzano on 3/28/12.
//  Copyright (c) 2012 GDIT. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Saved;

@interface ViewSavedController : UIViewController
{
    Saved *saved;
    IBOutlet UIWebView *webView;
}

@property (nonatomic, retain) Saved *saved;
@property (nonatomic, retain) UIWebView *webView;

- (void) createWebViewWithHTML;
@end
