//
//  EditScaleViewController.m
//  VAS002
//
//  Created by Hasan Edain on 2/17/11.
//  Copyright 2011 GDIT. All rights reserved.
//

#import "EditScaleViewController.h"
#import "Scale.h"
#import "FlurryUtility.h"
#import "VASAnalytics.h"
#import "VAS002AppDelegate.h"
#import "Error.h"

@implementation EditScaleViewController

@synthesize managedObjectContext;

@synthesize leftTextField;
@synthesize rightTextField;
@synthesize scale;

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];

	UIApplication *app = [UIApplication sharedApplication];
	VAS002AppDelegate *appDelegate = (VAS002AppDelegate*)[app delegate];
	self.managedObjectContext = appDelegate.managedObjectContext;	
	
	self.title = [NSString stringWithFormat:@"Edit Scale"];
	self.leftTextField.text = self.scale.minLabel;
	self.rightTextField.text = self.scale.maxLabel;
	[FlurryUtility report:EVENT_ADD_EDIT_SCALE_ACTIVITY];
	
	// Uncomment the following line to display an Edit button in the navigation bar for this view controller.
	UIBarButtonItem *saveButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(save:)];
	self.navigationItem.rightBarButtonItem = saveButton;
	[saveButton release];	
}

- (void)save:(id)sender {
	self.scale.minLabel = self.leftTextField.text;
	self.scale.maxLabel = self.rightTextField.text;
	
	NSError *error = nil;
	
	if ([self.managedObjectContext hasChanges] ) {
		if(![self.managedObjectContext save:&error]) {
			[Error showErrorByAppendingString:@"Unable to save scale edit." withError:error];
		}
	}
	
	[self.navigationController popViewControllerAnimated:YES];	
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return YES;
}

#pragma mark Text Editing
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	if (textField == leftTextField) {
		[leftTextField resignFirstResponder];
		[rightTextField becomeFirstResponder];
		self.scale.minLabel = leftTextField.text;
	}
	
	if (textField == rightTextField) {
		[rightTextField resignFirstResponder];
		self.scale.maxLabel = rightTextField.text;
	}
	
	NSError *error = nil;

	if ([self.managedObjectContext hasChanges] && ![self.managedObjectContext save:&error]) {
		[Error showErrorByAppendingString:@"Unable to save Category edit." withError:error];
	}
	
	return YES;	
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
	BOOL shouldChangeText = YES;
	
	NSCharacterSet *charactersToRemove = [[NSCharacterSet alphanumericCharacterSet] invertedSet];
	NSCharacterSet *punctuation = [NSCharacterSet punctuationCharacterSet];
	
	NSString *trimmedReplacement = [string stringByTrimmingCharactersInSet:charactersToRemove ];
	
	trimmedReplacement = [trimmedReplacement stringByTrimmingCharactersInSet:punctuation];
	
	if (![trimmedReplacement isEqual:string]) {
		shouldChangeText = NO;
	}
	
	return shouldChangeText;
}

#pragma mark Memory

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)dealloc {
	[self.managedObjectContext release];
	
	[self.leftTextField release];
	[self.rightTextField release];
	[self.scale release], self.scale = nil;
	
    [super dealloc];
}


@end
