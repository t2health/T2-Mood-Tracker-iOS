//
//  ViewSavedController.m
//  VAS002
//
//  Created by Melvin Manzano on 3/28/12.
//  Copyright (c) 2012 GDIT. All rights reserved.
//

#import "ViewSavedController.h"
#import "Saved.h"
#import "VAS002AppDelegate.h"
#import "Error.h"
#import <CoreData/CoreData.h>

@implementation ViewSavedController

@synthesize saved;
@synthesize webView;

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"View Result";
    
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceOrientationChanged:) name:UIDeviceOrientationDidChangeNotification object:nil];

    [self createWebViewWithHTML];
    
}


- (void) createWebViewWithHTML
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory , NSUserDomainMask, YES); 
    NSString *documentsDir = [paths objectAtIndex:0];
    NSString *filePath = [NSString stringWithFormat:@"%@%@",documentsDir, saved.filename];

    // read everything from text
    NSString* fileContents = [NSString stringWithContentsOfFile:filePath 
                              encoding:NSUTF8StringEncoding error:nil];

    // first, separate by new line
    NSArray* allLinedStrings = [fileContents componentsSeparatedByCharactersInSet:
     [NSCharacterSet newlineCharacterSet]];

    //create the string
    NSMutableString *html = [NSMutableString stringWithString: @"<html><head><title></title>"];
    [html appendString:@"<style type=\"text/css\">"];
    [html appendString:@"td.daterange { font-family:\"Arial\"; color: black; background-color: silver }"];
    [html appendString:@"td.date { font-family:\"Arial\"; color: black; background-color: white; font-size:12px; font-style:italic}"];
    [html appendString:@"td.scale { font-family:\"Arial\"; color: black; background-color: white }"];
    [html appendString:@"td.category { font-family:\"Arial\"; color: black; background-color: white }"];
    [html appendString:@"</style>"];
                             
                             
                             
                             
    [html appendString:@"</head><body style=\"background:transparant;\" topmargin='0' leftmargin='0' rightmargin='0'>"];
    NSString *prevDate = @"";
    NSString *prevCat = @"";
    //continue building the string
    [html appendString:@"<table cellpadding='3' cellspacing='0' border='0' width='100%'>"];
    
    [html appendString:[NSString stringWithFormat:@"<tr><td colspan='2' align='center' class='daterange'>Date Range: %@</td></tr>", saved.title ]];
    
    
    NSDateFormatter *dateFormat = [[[NSDateFormatter alloc] init] autorelease];
    
    [html appendString:@"<tr><td colspan='2' height='10'>&nbsp;</td></tr>"];
    
    for (int i=0; i < allLinedStrings.count; i++)
    {
        NSString *testString = [allLinedStrings objectAtIndex:i];
        if ([testString length] != 0) 
        {
            NSString *curLine = [allLinedStrings objectAtIndex:i];
            NSArray *curData = [curLine componentsSeparatedByString:@","];
            NSString *testDate = [curData objectAtIndex:0];

            [dateFormat setDateFormat:@"yyyy-MM-dd' 'HH:mm:ss' 'Z"];
            NSDate *date = [dateFormat dateFromString:testDate];
            [dateFormat setDateStyle:NSDateFormatterMediumStyle];
            [dateFormat setTimeStyle:NSDateFormatterShortStyle];
            NSString *dateString = [dateFormat stringFromDate:date];
            
            
            
            if (![prevDate isEqualToString:dateString] && ![prevDate isEqualToString:[curData objectAtIndex:1]]) 
            {
                [html appendString:[NSString stringWithFormat:@"<tr><td class='date'>%@</td><td></td></tr>", dateString]];
                [html appendString:[NSString stringWithFormat:@"<tr><td class='category'><b>%@</b></td><td></td></tr>", [curData objectAtIndex:1]]];
                [html appendString:[NSString stringWithFormat:@"<tr><td></td><td class='scale'>%@ - %@</td></tr>", [curData objectAtIndex:2], [curData objectAtIndex:3]]];                
                prevDate = dateString;
                prevCat = [curData objectAtIndex:1];
            }
            else
            {
                [html appendString:[NSString stringWithFormat:@"<tr><td></td><td class='scale'>%@ - %@</td></tr>", [curData objectAtIndex:2], [curData objectAtIndex:3]]];
            }
        }   
    }
    
    [html appendString:@"</table>"];
    [html appendString:@"</body></html>"];
    NSLog(@"html: %@", html);
    //make the background transparent
    [webView setBackgroundColor:[UIColor clearColor]];
    
    //pass the string to the webview
    [webView loadHTMLString:[html description] baseURL:nil];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

#pragma mark - Orientation

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}

- (void)deviceOrientationChanged:(NSNotification *)notification {
	UIDevice *device = [UIDevice currentDevice];
	if (device.orientation == UIDeviceOrientationPortrait || device.orientation == UIDeviceOrientationPortraitUpsideDown) 
    {
        //[webView reload];
       // [self createWebViewWithHTML];

	}
	else if(device.orientation == UIDeviceOrientationLandscapeLeft || device.orientation == UIDeviceOrientationLandscapeRight)
    {
        

	}

}


@end
