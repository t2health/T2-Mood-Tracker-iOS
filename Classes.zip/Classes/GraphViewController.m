//
//  GraphViewController.m
//  VAS002
//
//  Created by Melvin Manzano on 4/24/12.
//  Copyright (c) 2012 GDIT. All rights reserved.
//

#import "GraphViewController.h"
#import "SubGraphViewController.h"
#import "VAS002AppDelegate.h"
#import "Result.h"
#import "FlurryUtility.h"
#import "VASAnalytics.h"
#import "Group.h"
#import "ViewNotesViewController.h"
#import "Error.h"
#import "Note.h"
#import "GroupResult.h"
#import "DateMath.h"
#import "AddNoteViewController.h"

@implementation GraphViewController

@synthesize menuView, containterView, graphView;
@synthesize managedObjectContext;

@synthesize switchDictionary;
@synthesize ledgendColorsDictionary;
@synthesize groupsDictionary, groupsArray;
CGRect menu_ShownFrame;
CGRect menu_HiddenFrame;	
bool menuShowing;

#pragma mark - View lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    menuShowing = NO;

    UIApplication *app = [UIApplication sharedApplication];
	VAS002AppDelegate *appDelegate = (VAS002AppDelegate *)[app delegate];
	self.managedObjectContext = appDelegate.managedObjectContext;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceOrientationChanged:) name:UIDeviceOrientationDidChangeNotification object:nil];
    
    [self fillGroupsDictionary];
	[self fillColors];
	[self createSwitches];
    
    [self setupGraph];

    
    UIImage *image = [UIImage imageNamed:@"tab-settings-inactive.png"];
    UIBarButtonItem *optionButton = [[UIBarButtonItem alloc] initWithImage:image style:UIBarButtonItemStyleBordered target:self action:@selector(optionButtonClicked)];
	self.navigationItem.rightBarButtonItem = optionButton;
	[optionButton release];
}

-(void) viewWillDisappear:(BOOL)animated {
    if ([self.navigationController.viewControllers indexOfObject:self]==NSNotFound) {
        // back button was pressed.  We know this is true because self is no longer
        // in the navigation stack.  
        
        [self removeMenu];
        
    }
    [super viewWillDisappear:animated];
}


#pragma mark Graph Menu 
- (IBAction)cancelMenu:sender;
{
    [self hideMenu];
}

- (void)removeMenu
{
    
    menuView.hidden = YES;

}

- (void)hideMenu
{
    menuShowing = NO;
    [UIView beginAnimations:nil context:NULL] ;
    [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
    [UIView setAnimationDuration:0.3f];
    [menuView setFrame:menu_HiddenFrame];
    [UIView commitAnimations] ;

    [NSTimer timerWithTimeInterval:(0.2f) target:self selector:@selector(removeMenu) userInfo:nil repeats:NO];
}

- (void)optionButtonClicked
{
    if (menuShowing) 
    {
        [self hideMenu];
    }
    else 
    {
        [self showMenu];
    }
}

- (void)showMenu
{

    
    //[menuView removeFromSuperview];
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) 
    {
        // ipad
        NSLog(@"show menu display ipad....");
        
        /*
         notes_HiddenFrame = noteTempView.frame;
         
         notes_HiddenFrame.origin.y =  1024;   
         notes_HiddenFrame.origin.x = 0; 
         
         [noteTempView setFrame:notes_HiddenFrame];
         [self.window addSubview:noteTempView];
         
         notes_ShownFrame = noteTempView.frame;
         notes_ShownFrame.origin.y =  20; 
         
         
         [UIView beginAnimations:nil context:NULL] ;
         [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
         [UIView setAnimationDuration:0.3f];
         [noteTempView setFrame:notes_ShownFrame];
         [UIView commitAnimations];
         */
        
        
    }
    else // iphone
    {
        //GraphMenuViewController *graphMenuViewController = [[GraphMenuViewController alloc] initWithNibName:@"GraphMenuViewController" bundle:nil];
        //menuTempView = graphMenuViewController.view;	

        menuShowing = YES;
        UIDevice *device = [UIDevice currentDevice];
        if (device.orientation == UIDeviceOrientationPortrait || device.orientation == UIDeviceOrientationPortraitUpsideDown) 
        {
            menu_HiddenFrame = menuView.frame;
            menu_HiddenFrame.origin.y =  420;   
            menu_HiddenFrame.origin.x = 0; 
            
            [menuView setFrame:menu_HiddenFrame];
            [self.view addSubview:menuView];
            
            menu_ShownFrame = menuView.frame;
            menu_ShownFrame.origin.y =  160; 
            
            [UIView beginAnimations:nil context:NULL] ;
            [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
            [UIView setAnimationDuration:0.3f];
            [menuView setFrame:menu_ShownFrame];
            [UIView commitAnimations] ;
            
            
        }
        else if(device.orientation == UIDeviceOrientationLandscapeLeft || device.orientation == UIDeviceOrientationLandscapeRight)
        {
            menu_HiddenFrame = menuView.frame;
            menu_HiddenFrame.origin.y = 0;   
            menu_HiddenFrame.origin.x = 480; 
            
            [menuView setFrame:menu_HiddenFrame];
            [self.view addSubview:menuView];
            
            menu_ShownFrame = menuView.frame;
            menu_ShownFrame.origin.x =  160; 
            
            [UIView beginAnimations:nil context:NULL] ;
            [UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
            [UIView setAnimationDuration:0.3f];
            [menuView setFrame:menu_ShownFrame];
            [UIView commitAnimations] ;
            
            
        }
        
    }
    
}

- (void)setupGraph
{
    containterView.backgroundColor = [UIColor colorWithRed:26.f/255.f green:25.f/255.f blue:25.f/255.f alpha:1.f];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        /*
        UIImageView *headerView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo_black.png"]];
        [headerView setFrame:CGRectMake((self.view.bounds.size.width-446) /2, 0, 446, 92)];
        headerView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
        [self.view addSubview:headerView];
        [headerView release];
        */
        //Create the chart
        chart = [[ShinobiChart alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height-75)];
    } else {
        //Create the chart
        chart = [[ShinobiChart alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    }
    
    // Set a different theme on the chart
    SChartMidnightTheme *midnight = [[SChartMidnightTheme alloc] init];
    [chart setTheme:midnight];
    [midnight release];
    
    //As the chart is a UIView, set its resizing mask to allow it to automatically resize when screen orientation changes.
    chart.autoresizingMask = ~UIViewAutoresizingNone;
    
    // Initialise the data source we will use for the chart
    datasource = [[GraphDataSource alloc] init];
    
    // Give the chart the data source
    chart.datasource = datasource;
    
    // Create a date time axis to use as the x axis.    
    SChartDateTimeAxis *xAxis = [[SChartDateTimeAxis alloc] init];
    // Enable panning and zooming on the x-axis.
    xAxis.enableGesturePanning = YES;
    xAxis.enableGestureZooming = YES;
    xAxis.enableMomentumPanning = YES;
    xAxis.enableMomentumZooming = YES;
    xAxis.axisPositionValue = [NSNumber numberWithInt: 0];
    
    chart.xAxis = xAxis;
    [xAxis release];
    
    //Create a number axis to use as the y axis.
    SChartNumberAxis *yAxis = [[SChartNumberAxis alloc] init];

    
    //Enable panning and zooming on Y
    yAxis.enableGesturePanning = YES;
    yAxis.enableGestureZooming = YES;
    yAxis.enableMomentumPanning = YES;
    yAxis.enableMomentumZooming = YES;
    
    
    
    chart.yAxis = yAxis;
    
    //Set the chart title
    chart.title = @"Results";
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        chart.titleLabel.font = [UIFont fontWithName:@"TrebuchetMS" size:27.0f];
    } else {
        chart.titleLabel.font = [UIFont fontWithName:@"TrebuchetMS" size:17.0f];
    }
    chart.titleLabel.textColor = [UIColor whiteColor];
    
    // If you have a trial version, you need to enter your licence key here:
    //    chart.licenseKey = @"";
    
    // Add the chart to the view controller
    [containterView addSubview:chart];
    
    /*
    // Create a switch to toggle lineSeries/stepLineSeries
    
    stepSwitch = [[UISwitch alloc] initWithFrame: CGRectZero];
    [stepSwitch addTarget: self action:(@selector(switchSeriesType)) forControlEvents:UIControlEventValueChanged];
    [stepSwitch setHidden: NO];
    [stepSwitch setAutoresizingMask: ~UIViewAutoresizingNone];
    [self.view addSubview: stepSwitch];
    CGRect switchFrame = CGRectMake(self.view.bounds.size.width/2.f + 5.f,
                                    (self.view.bounds.size.height + chart.frame.origin.y + chart.bounds.size.height)/2.f - stepSwitch.bounds.size.height,
                                    stepSwitch.bounds.size.width,
                                    stepSwitch.bounds.size.height);
    [stepSwitch setFrame: switchFrame];
    
    
    // And a label to go with it
    stepLabel = [[UILabel alloc] initWithFrame: CGRectZero];
    [stepLabel setHidden: NO];
    [stepLabel setAutoresizingMask: ~UIViewAutoresizingNone];
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        [stepLabel setFont: [UIFont systemFontOfSize: 24.f]];
    } else {
        [stepLabel setFont: [UIFont systemFontOfSize: 14.f]];
    }
    [stepLabel setText: @"Step Line:"];
    [stepLabel setTextColor: [UIColor whiteColor]];
    [stepLabel setBackgroundColor: [UIColor colorWithRed:26.f/255.f green:25.f/255.f blue:25.f/255.f alpha:1.f]];
    [stepLabel sizeToFit];
    [self.view addSubview: stepLabel];
    CGRect labelFrame = CGRectMake(self.view.bounds.size.width/2.f - stepLabel.bounds.size.width - 5.f,
                                   (self.view.bounds.size.height + chart.frame.origin.y + chart.bounds.size.height)/2.f - stepLabel.bounds.size.height,
                                   stepLabel.bounds.size.width, 
                                   stepLabel.bounds.size.height);
    [stepLabel setFrame: labelFrame];

    */
}

-(void)switchSeriesType {
    double xMin, xMax, yMin, yMax;
    xMin = [chart.xAxis.axisRange.minimum doubleValue];
    xMax = [chart.xAxis.axisRange.maximum doubleValue];
    yMin = [chart.yAxis.axisRange.minimum doubleValue];
    yMax = [chart.yAxis.axisRange.maximum doubleValue];
    
    // Change series type
    [datasource toggleSeriesType];
    
    // Reload data
    [chart reloadData];
    [chart layoutSubviews];
    
    // Restore axes' ranges
    [chart.xAxis setRangeWithMinimum:[NSNumber numberWithDouble: xMin] andMaximum:[NSNumber numberWithDouble: xMax] withAnimation:NO];
    [chart.yAxis setRangeWithMinimum:[NSNumber numberWithDouble: yMin] andMaximum:[NSNumber numberWithDouble: yMax] withAnimation:NO];
    
    // Redraw chart
    [chart redrawChartAndGL: YES];
}

#pragma mark Rotation

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
	//return (interfaceOrientation == UIInterfaceOrientationPortrait);
	BOOL shouldRotate = NO;	
	
	if (interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown) 
    {
		shouldRotate = YES;
	}
	
	if (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight) 
    {
		shouldRotate = YES;
	}
	
	return shouldRotate;
}

- (void)deviceOrientationChanged:(NSNotification *)notification 
{
    [menuView removeFromSuperview];
    if (menuShowing == 1) 
    {
        menuShowing = NO;
      //  [menuView removeFromSuperview];
    }
}



#pragma mark switch

-(void)createSwitches {
	if (self.switchDictionary == nil) {
		self.switchDictionary = [NSMutableDictionary dictionary];
		
		NSInteger switchWidth = 96;
		NSInteger height = 24;
		NSInteger xOff = 8;
		NSInteger yOff = 8;
		
		CGRect switchRect = CGRectMake(xOff, yOff , switchWidth, height);
		
		NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
		BOOL storedVal;
		NSString *key;
		
		NSArray *grpArray = [[self.groupsDictionary allKeys] sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
		for (NSString *groupTitle in grpArray) {			
			UISwitch *aSwitch = [[UISwitch alloc] initWithFrame:switchRect];
			key = [NSString stringWithFormat:@"SWITCH_STATE_%@",groupTitle];
			if (![defaults objectForKey:key]) {
				storedVal = YES;
			}
			else {
				storedVal = [defaults boolForKey:key];				
			}
            
			aSwitch.on = storedVal;
			aSwitch.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin + UIViewAutoresizingFlexibleBottomMargin; 
			[aSwitch addTarget:self action:@selector(switchFlipped:) forControlEvents:UIControlEventValueChanged];
			
			[self.switchDictionary setValue:aSwitch forKey:groupTitle];
			[aSwitch release];
		}
	}
}

-(void)switchFlipped:(id)sender {
	NSEnumerator *enumerator = [self.switchDictionary keyEnumerator];
	id key;
	
	UISwitch *currentValue;
	NSString *switchTitle = @"";
	
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSString *defaultsKey;
	
	while ((key = [enumerator nextObject])) {
		currentValue = [self.switchDictionary objectForKey:key];
		if (currentValue == sender) {
			switchTitle = key;
			defaultsKey = [NSString stringWithFormat:@"SWITCH_STATE_%@",switchTitle];
			BOOL val = ((UISwitch *)currentValue).on;
			[defaults setBool:val forKey:defaultsKey];
			[defaults synchronize];
			NSDictionary *usrDict = [NSDictionary dictionaryWithObjectsAndKeys:switchTitle, [NSNumber numberWithBool:val],nil];
			[FlurryUtility report:EVENT_GRAPHRESULTS_SWITCHFLIPPED withData:usrDict];
		}
	}
	
// reload chart somehow
}

#pragma mark groups

- (void)fillGroupsDictionary {
	if (self.groupsDictionary == nil) {
		NSMutableDictionary *groups = [NSMutableDictionary dictionary];
		NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
		
		NSEntityDescription *entity = [NSEntityDescription entityForName:@"Group" inManagedObjectContext:self.managedObjectContext];
		[fetchRequest setEntity:entity];
        
		NSPredicate *groupPredicate = [NSPredicate predicateWithFormat:@"(showGraph == YES)"];
		NSPredicate *visiblePredicate = [NSPredicate predicateWithFormat:@"(visible == YES)"];
		
		NSArray *finalPredicateArray = [NSArray arrayWithObjects:groupPredicate,visiblePredicate, nil];
		NSPredicate *finalPredicate = [NSCompoundPredicate andPredicateWithSubpredicates:finalPredicateArray];
		[fetchRequest setPredicate:finalPredicate];
        
		NSError *error = nil;
		NSArray *objects = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
		if (error) {
			[Error showErrorByAppendingString:@"Unable to get Categories to graph" withError:error];
		}
		
		[fetchRequest release];
		
		for (Group *aGroup in objects) {
			[groups setObject:aGroup forKey:aGroup.title];
		}			
		self.groupsDictionary = [NSDictionary dictionaryWithDictionary:groups];
		
		NSArray *keys = [self.groupsDictionary allKeys];
		NSArray *sortedKeys = [keys sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
		
		NSMutableArray *grpArray = [NSMutableArray array];
		for (NSString *groupName in sortedKeys) {
			[grpArray addObject:[self.groupsDictionary objectForKey:groupName]];
		}
		self.groupsArray = [NSArray arrayWithArray:grpArray];
	}
}

#pragma mark colors

-(UIColor *)UIColorForIndex:(NSInteger)index {
	NSArray *colorsArray = [NSArray arrayWithObjects:[UIColor blueColor], [UIColor greenColor], [UIColor orangeColor], [UIColor redColor], [UIColor purpleColor], [UIColor grayColor], [UIColor brownColor],	[UIColor cyanColor],[UIColor magentaColor],  nil];
	
	UIColor *color = nil;
	
	if (index >=0 && index < [colorsArray count]) {
		color = [colorsArray objectAtIndex:index];
		[[color retain] autorelease];
	}
	return color;
}

-(CPColor *)CPColorForIndex:(NSInteger)index {
	NSArray *colorsArray = [NSArray arrayWithObjects:[CPColor blueColor], [CPColor greenColor], [CPColor orangeColor], [CPColor redColor], [CPColor purpleColor], [CPColor grayColor], [CPColor brownColor],	[CPColor cyanColor],[CPColor magentaColor],  nil];
	
	CPColor *color = nil;
	
	if (index >=0 && index < [colorsArray count]) {
		color = [colorsArray objectAtIndex:index];
		[[color retain] autorelease];
	}
	return color;
}
- (void)fillColors {
	if (self.ledgendColorsDictionary == nil) {
		self.ledgendColorsDictionary = [NSMutableDictionary dictionary];
		
		NSArray *objects = [self.groupsDictionary allKeys];
		NSInteger index = 0;
		
		for (NSString *groupTitle in objects) {
			UIColor *color = [self UIColorForIndex:index];
			[self.ledgendColorsDictionary setObject:color forKey:groupTitle];
			index++;
		}
	}
    
    //  NSLog(@"colorDict: %@", ledgendColorsDictionary);
}


#pragma mark tableView
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
	return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
	NSInteger numberOfRows = [self.groupsDictionary count];
	return numberOfRows;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier] autorelease];
    }
    
    // Configure the cell...
    [self configureCell:cell atIndexPath:indexPath];
	
    return cell;
}

- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath {	
	// Configure the cell to show the book's title
	NSInteger row = [indexPath indexAtPosition:1];
	
	Group *group = [self.groupsArray objectAtIndex:row];
	NSString *groupName = group.title;
	UISwitch *aSwitch = [self.switchDictionary objectForKey:groupName];
	cell.accessoryView = aSwitch;
	
	cell.textLabel.text = groupName;
	cell.textLabel.textColor = [self.ledgendColorsDictionary objectForKey:groupName];
	cell.textLabel.font = [UIFont boldSystemFontOfSize:14];
	cell.textLabel.textAlignment = UITextAlignmentRight;
}



-(void)dealloc {
    [chart release];
    [datasource release];
    [super dealloc];
}



@end
