//
//  Tip.h
//  VAS002
//
//  Created by Roger Reeder on 11/11/10.
//  Copyright 2010 GDIT. All rights reserved.
//

#import <CoreData/CoreData.h>


@interface Tip :  NSManagedObject  
{
}

@property (nonatomic, retain) NSString * tip;

@end



