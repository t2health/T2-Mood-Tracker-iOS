// 
//  GroupResult.m
//  VAS002
//
//  Created by Hasan Edain on 1/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GroupResult.h"

#import "Group.h"

@implementation GroupResult 

@dynamic value;
@dynamic day;
@dynamic month;
@dynamic year;
@dynamic group;

@end
