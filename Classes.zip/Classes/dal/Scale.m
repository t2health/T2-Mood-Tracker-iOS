// 
//  Scale.m
//  VAS002
//
//  Created by Roger Reeder on 11/11/10.
//  Copyright 2010 GDIT. All rights reserved.
//

#import "Scale.h"

#import "Group.h"
#import "Result.h"

@implementation Scale 

@dynamic minLabel;
@dynamic weight;
@dynamic maxLabel;
@dynamic group;
@dynamic result;
@dynamic index;

@end
