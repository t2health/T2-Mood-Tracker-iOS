//
//  HelpViewController.h
//  VAS002
//
//  Created by Hasan Edain on 12/27/10.
//  Copyright 2010 GDIT. All rights reserved.
//

@interface HelpViewController : UIViewController {
	IBOutlet UIWebView *helpWebView;
}

@property (nonatomic, retain) UIWebView *helpWebView;

@end
