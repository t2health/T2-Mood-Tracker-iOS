//
//  GraphViewController.h
//  VAS002
//
//  Created by Melvin Manzano on 4/24/12.
//  Copyright (c) 2012 GDIT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <CoreData/CoreData.h>
#import <ShinobiCharts/ShinobiChart.h>
#import "GraphDataSource.h"
#import "AddNoteViewController.h"

@interface GraphViewController : UIViewController <SChartDelegate, UITableViewDelegate, UITableViewDataSource> 
{
    
    ShinobiChart            *chart;
    GraphDataSource         *datasource;    
    UISwitch                *stepSwitch;
    UILabel                 *stepLabel;

    IBOutlet UIView *menuView;
    IBOutlet UIView *containterView;
    IBOutlet UIView *graphView;
    
    NSManagedObjectContext *managedObjectContext;
    
    NSMutableDictionary *switchDictionary;
	NSMutableDictionary *ledgendColorsDictionary;
	NSDictionary *groupsDictionary;
    NSArray *groupsArray;
        
    
}

@property (nonatomic, retain) IBOutlet UIView *menuView;
@property (nonatomic, retain) IBOutlet UIView *containterView;
@property (nonatomic, retain) IBOutlet UIView *graphView;
@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain) NSMutableDictionary *switchDictionary;
@property (nonatomic, retain) NSMutableDictionary *ledgendColorsDictionary;
@property (nonatomic, retain) NSDictionary *groupsDictionary;
@property (nonatomic, retain) NSArray *groupsArray;



- (void)showMenu;
- (void)hideMenu;
- (void)removeMenu;
- (IBAction)cancelMenu:sender;

- (void)optionButtonClicked;

- (void)createSwitches;
- (void)switchFlipped:(id)sender;
- (void)fillGroupsDictionary;
- (void)fillColors;


- (void)deviceOrientationChanged:(NSNotification *)notification;


@end
