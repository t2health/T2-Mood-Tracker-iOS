//
//  ImproveApplicationViewController.h
//  VAS002
//
//  Created by Hasan Edain on 1/26/11.
//  Copyright 2011 GDIT. All rights reserved.
//


@interface ImproveApplicationViewController : UIViewController {
	IBOutlet UISwitch *useFlurrySwitch;
}

- (IBAction)useFlurrySwitchChanged;

@end
