//
//  EditScaleViewController.h
//  VAS002
//
//  Created by Hasan Edain on 2/17/11.
//  Copyright 2011 GDIT. All rights reserved.
//

#import <CoreData/CoreData.h>

@class Scale;

@interface EditScaleViewController : UIViewController <UITextViewDelegate> {
	NSManagedObjectContext *managedObjectContext;

	IBOutlet UITextField *leftTextField;
	IBOutlet UITextField *rightTextField;
	Scale *scale;
}

@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;

@property (nonatomic, retain) IBOutlet UITextField *leftTextField;
@property (nonatomic, retain) IBOutlet UITextField *rightTextField;
@property (nonatomic, retain)Scale *scale;

- (void)save:(id)sender;

@end
