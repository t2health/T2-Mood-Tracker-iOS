//
//  GraphDataSource.h
//  VAS002
//
//  Created by Melvin Manzano on 5/2/12.
//  Copyright (c) 2012 GDIT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ShinobiCharts/ShinobiChart.h>
#import <CoreData/CoreData.h>
#import "VAS002AppDelegate.h"
#import "Result.h"
#import "FlurryUtility.h"
#import "VASAnalytics.h"
#import "Group.h"
#import "ViewNotesViewController.h"
#import "Error.h"
#import "Note.h"
#import "GroupResult.h"
#import "DateMath.h"

@interface GraphDataSource : NSObject <SChartDatasource>
{
    NSCalendar *cal; //Calendar used for constructing date objects.
    BOOL stepLineMode;
    
    NSManagedObjectContext *managedObjectContext;
    NSInteger chartMonth;
    NSInteger chartYear;
    BOOL dateSet;
    NSMutableDictionary *switchDictionary;
    NSMutableDictionary *ledgendColorsDictionary;
    NSDictionary *groupsDictionary;
    NSArray *groupsArray;
    NSCalendar *gregorian;
    
    NSArray *notesForMonth;
    NSDictionary *valuesArraysForMonth;
}

@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain) NSCalendar* gregorian;
@property (nonatomic, retain) NSArray *notesForMonth;
@property (nonatomic, retain) NSDictionary *valuesArraysForMonth;
@property (nonatomic, assign) NSInteger chartMonth;
@property (nonatomic, assign) NSInteger chartYear;
@property (nonatomic, assign) BOOL dateSet;
@property (nonatomic, retain) NSMutableDictionary *switchDictionary;
@property (nonatomic, retain) NSMutableDictionary *ledgendColorsDictionary;
@property (nonatomic, retain) NSDictionary *groupsDictionary;
@property (nonatomic, retain) NSArray *groupsArray;

@property (nonatomic, retain) NSMutableArray *series1Data, *series1Dates, *series2Data, *series2Dates;

-(void)toggleSeriesType;
- (NSArray *)getValueArray;
@end
