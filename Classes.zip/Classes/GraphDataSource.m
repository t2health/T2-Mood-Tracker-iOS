//
//  GraphDataSource.m
//  VAS002
//
//  Created by Melvin Manzano on 5/2/12.
//  Copyright (c) 2012 GDIT. All rights reserved.
//

#import "GraphDataSource.h"
#import "VAS002AppDelegate.h"
#import "Result.h"
#import "FlurryUtility.h"
#import "VASAnalytics.h"
#import "Group.h"
#import "ViewNotesViewController.h"
#import "Error.h"
#import "Note.h"
#import "GroupResult.h"
#import "DateMath.h"

@implementation GraphDataSource

@synthesize series1Data, series1Dates, series2Data, series2Dates;
@synthesize managedObjectContext;
@synthesize chartMonth;
@synthesize chartYear;
@synthesize dateSet;
@synthesize switchDictionary;
@synthesize ledgendColorsDictionary;
@synthesize groupsDictionary;
@synthesize groupsArray;
@synthesize gregorian;
@synthesize notesForMonth;
@synthesize valuesArraysForMonth;


- (id)init
{
    self = [super init];
    if (self) {
        // Initialize the calendar
        cal = [[NSCalendar currentCalendar] retain];
        stepLineMode = NO;
        
        NSArray *rawData;
        
        UIApplication *app = [UIApplication sharedApplication];
        VAS002AppDelegate *appDelegate = (VAS002AppDelegate *)[app delegate];
        self.managedObjectContext = appDelegate.managedObjectContext;
        
        [self fillGroupsDictionary];
        [self fillColors];
        [self createSwitches];
        
        
        NSArray *tempArray= [NSArray arrayWithArray:[self getValueArray]];
        
        series1Data = [[NSMutableArray alloc] init];
        series1Dates = [[NSMutableArray alloc] init];

        for (int i = 0; i < [tempArray count]; i += 3) 
        {
             // read in date axis
                 
             NSString * dateString = [tempArray objectAtIndex:i];
             NSDate *date = [self dateFromString:dateString];
             [series1Dates addObject:date];

             // read in data series
             [series1Data addObject:[tempArray objectAtIndex:(i + 1)]];

        }

         NSLog(@"series1Dates: %@", series1Dates);
 
    }
    
    return self;
}

- (NSDate *)dateFromString:(NSString *)str
{
    static BOOL monthLookupTableInitialised = NO;
    static NSMutableArray *monthIdx;
    static NSArray *monthNames;
    static NSDictionary *months;
    
    if (!monthLookupTableInitialised) {
        monthIdx = [[NSMutableArray alloc] init ];
        for (int i = 1; i <= 12; ++i) {
            [monthIdx addObject:[NSNumber numberWithInt:i]];
        }
        
        monthNames = [[NSArray alloc] initWithObjects:@"Jan", @"Feb", @"Mar", @"Apr", @"May", @"Jun", @"Jul", @"Aug", @"Sep", @"Oct", @"Nov", @"Dec", nil];
        months = [[NSDictionary alloc] initWithObjects:monthIdx forKeys:monthNames];
        monthLookupTableInitialised = YES;
    }
    
    NSRange dayRange = NSMakeRange(0,2);
    NSString *dayString = [str substringWithRange:dayRange];
    NSUInteger day = [dayString intValue];
    
    NSRange monthRange = NSMakeRange(3, 3);
    NSString *monthString = [str substringWithRange:monthRange];
    NSUInteger month = [[months objectForKey:monthString] unsignedIntValue];
    
    NSRange yearRange = NSMakeRange(7, 4);
    NSString *yearString = [str substringWithRange:yearRange];
    NSUInteger year = [yearString intValue];
    
    NSDateComponents *components = [[NSDateComponents alloc] init];
    [components setDay:day];
    [components setMonth:month];
    [components setYear:year];
    
    gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDate *date = [gregorian dateFromComponents:components];
    
    [components release];
    [gregorian release];
    
    return date;
}

#pragma mark Data

#pragma mark Switches

-(void)createSwitches {
	if (self.switchDictionary == nil) {
		self.switchDictionary = [NSMutableDictionary dictionary];
		
		NSInteger switchWidth = 96;
		NSInteger height = 24;
		NSInteger xOff = 8;
		NSInteger yOff = 8;
		
		CGRect switchRect = CGRectMake(xOff, yOff , switchWidth, height);
		
		NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
		BOOL storedVal;
		NSString *key;
		
		NSArray *grpArray = [[self.groupsDictionary allKeys] sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
		for (NSString *groupTitle in grpArray) {			
			UISwitch *aSwitch = [[UISwitch alloc] initWithFrame:switchRect];
			key = [NSString stringWithFormat:@"SWITCH_STATE_%@",groupTitle];
			if (![defaults objectForKey:key]) {
				storedVal = YES;
			}
			else {
				storedVal = [defaults boolForKey:key];				
			}
            
			aSwitch.on = storedVal;
			aSwitch.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin + UIViewAutoresizingFlexibleBottomMargin; 
			[aSwitch addTarget:self action:@selector(switchFlipped:) forControlEvents:UIControlEventValueChanged];
			
			[self.switchDictionary setValue:aSwitch forKey:groupTitle];
			[aSwitch release];
		}
	}
}

#pragma mark Colors
-(UIColor *)UIColorForIndex:(NSInteger)index {
	NSArray *colorsArray = [NSArray arrayWithObjects:[UIColor blueColor], [UIColor greenColor], [UIColor orangeColor], [UIColor redColor], [UIColor purpleColor], [UIColor grayColor], [UIColor brownColor],	[UIColor cyanColor],[UIColor magentaColor],  nil];
	
	UIColor *color = nil;
	
	if (index >=0 && index < [colorsArray count]) {
		color = [colorsArray objectAtIndex:index];
		[[color retain] autorelease];
	}
	return color;
}

- (void)fillColors {
	if (self.ledgendColorsDictionary == nil) {
		self.ledgendColorsDictionary = [NSMutableDictionary dictionary];
		
		NSArray *objects = [self.groupsDictionary allKeys];
		NSInteger index = 0;
		
		for (NSString *groupTitle in objects) {
			UIColor *color = [self UIColorForIndex:index];
			[self.ledgendColorsDictionary setObject:color forKey:groupTitle];
			index++;
		}
	}
    
   // NSLog(@"colorDict: %@", ledgendColorsDictionary);
}

#pragma mark Groups
- (void)fillGroupsDictionary {
	if (self.groupsDictionary == nil) {
		NSMutableDictionary *groups = [NSMutableDictionary dictionary];
		NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
		
		NSEntityDescription *entity = [NSEntityDescription entityForName:@"Group" inManagedObjectContext:self.managedObjectContext];
		[fetchRequest setEntity:entity];
        
		NSPredicate *groupPredicate = [NSPredicate predicateWithFormat:@"(showGraph == YES)"];
		NSPredicate *visiblePredicate = [NSPredicate predicateWithFormat:@"(visible == YES)"];
		
		NSArray *finalPredicateArray = [NSArray arrayWithObjects:groupPredicate,visiblePredicate, nil];
		NSPredicate *finalPredicate = [NSCompoundPredicate andPredicateWithSubpredicates:finalPredicateArray];
		[fetchRequest setPredicate:finalPredicate];
        
		NSError *error = nil;
		NSArray *objects = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
		if (error) {
			[Error showErrorByAppendingString:@"Unable to get Categories to graph" withError:error];
		}
		
		[fetchRequest release];
		
		for (Group *aGroup in objects) {
			[groups setObject:aGroup forKey:aGroup.title];
		}			
		self.groupsDictionary = [NSDictionary dictionaryWithDictionary:groups];
		
		NSArray *keys = [self.groupsDictionary allKeys];
		NSArray *sortedKeys = [keys sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
		
		NSMutableArray *grpArray = [NSMutableArray array];
		for (NSString *groupName in sortedKeys) {
			[grpArray addObject:[self.groupsDictionary objectForKey:groupName]];
		}
		self.groupsArray = [NSArray arrayWithArray:grpArray];
        // NSLog(@"grpArray: %@", grpArray);
	}
}

- (NSArray *)getValueArray
{
    NSMutableArray *arrayByDate = [[NSMutableArray alloc] init];
    NSMutableArray *valueArray = [[NSMutableArray alloc] init];
    [arrayByDate addObject:@"0"];
    
	NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
	NSEntityDescription *entity = [NSEntityDescription entityForName:@"GroupResult" inManagedObjectContext:self.managedObjectContext];
	[fetchRequest setEntity:entity];
	
	// Create the sort descriptors array.
	NSSortDescriptor *yearDescriptor = [[NSSortDescriptor alloc] initWithKey:@"year" ascending:YES];
	NSSortDescriptor *monthDescriptor = [[NSSortDescriptor alloc] initWithKey:@"month" ascending:YES];
	NSSortDescriptor *dayDescriptor = [[NSSortDescriptor alloc] initWithKey:@"day" ascending:YES];
	NSSortDescriptor *groupTitleDescriptor = [[NSSortDescriptor alloc] initWithKey:@"group.title" ascending:YES];
	
	NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:yearDescriptor, monthDescriptor,dayDescriptor, groupTitleDescriptor, nil];
	[fetchRequest setSortDescriptors:sortDescriptors];
	
	NSString *groupPredicateString = @"";
	
	NSArray *results;
	NSPredicate *titlePredicate;
	NSPredicate *visiblePredicate;
	NSArray *finalPredicateArray;
	NSPredicate *finalPredicate;

    
	for (NSString *groupTitle in self.groupsDictionary) 
    {
		//Group *currentGroup = [self.groupsDictionary objectForKey:groupTitle];
		UISwitch *currentSwitch = [switchDictionary objectForKey:groupTitle];
		if (currentSwitch.on == YES) {
			groupPredicateString = [NSString stringWithFormat:@"group.title like %%@"];
            
			titlePredicate = [NSPredicate predicateWithFormat:groupPredicateString, groupTitle];
			visiblePredicate = [NSPredicate predicateWithFormat:@"group.visible == TRUE"];
			finalPredicateArray = [NSArray arrayWithObjects:titlePredicate,visiblePredicate, nil];
			finalPredicate = [NSCompoundPredicate andPredicateWithSubpredicates:finalPredicateArray];
			[fetchRequest setPredicate:finalPredicate];
			[fetchRequest setFetchBatchSize:0];
			
			NSError *error = nil;
			results = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];

			if (error) {
				[Error showErrorByAppendingString:@"could not get result data for graph" withError:error];
			} 
			else 
            {
                NSMutableArray *tempTotalArray = [[NSMutableArray alloc] init];
                NSMutableArray *tempCountArray = [[NSMutableArray alloc] init];
                
                
                if (results.count > 0) 
                { 
                    int value = 0;
                    int day = 0;
                    int month = 0;
                    int year = 0; 
                    NSString *nn = @"";
                    NSString *monthStr = @"";
                    NSString *dayStr = @"";
                    
                    // Set up temp arrays for averaging
                    for (GroupResult *groupResult in results) 
                    {
                        value = [groupResult.value intValue];
                        day = [groupResult.day intValue] - 1;
                        month = [groupResult.month intValue];
                        year = [groupResult.year intValue]; 
                        nn = groupResult.group.title;
                        
                        // Yah yah, dateformatter would have been better....
                        if (month == 1) {monthStr = @"Jan";}
                        if (month == 2) {monthStr = @"Feb";}
                        if (month == 3) {monthStr = @"Mar";}
                        if (month == 4) {monthStr = @"Apr";}
                        if (month == 5) {monthStr = @"May";}
                        if (month == 6) {monthStr = @"Jun";}
                        if (month == 7) {monthStr = @"Jul";}
                        if (month == 8) {monthStr = @"Aug";}
                        if (month == 9) {monthStr = @"Sep";}
                        if (month == 10) {monthStr = @"Oct";}
                        if (month == 11) {monthStr = @"Nov";}
                        if (month == 12) {monthStr = @"Dec";}
                        
                        if ([[NSString stringWithFormat:@"%i",day] length] < 2) 
                        {
                            dayStr = [NSString stringWithFormat:@"0%i",day];
                        }
                        else 
                        {
                            dayStr = [NSString stringWithFormat:@"%i",day];
                        }
                        
                        // Convert Date 
                        NSString *dateString = [NSString stringWithFormat:@"%@-%@-%i", dayStr, monthStr, year];


                        [tempTotalArray addObject:[NSString stringWithFormat:@"%@",dateString]];
                        [tempTotalArray addObject:[NSString stringWithFormat:@"%i",value]];
                        [tempTotalArray addObject:[NSString stringWithFormat:@"%@",nn]];
                        
                        [tempCountArray addObject:[NSString stringWithFormat:@"%@",dateString]];
                        [tempCountArray addObject:[NSString stringWithFormat:@"%i",value]];
                        [tempCountArray addObject:[NSString stringWithFormat:@"%@",nn]];
                        
                    }

                    bool doesExist = NO;
                    
                    for (int i = 0; i < tempTotalArray.count; i+=3) 
                    {
                        doesExist = NO;
                        
                        for (int a = 0; a < arrayByDate.count; a++) 
                        {
                            //NSLog(@"arrayByDate:%@ count:%i",[arrayByDate objectAtIndex:a], a);
                            //NSLog(@"tempTotalArray:%@ count:%i",[tempTotalArray objectAtIndex:i], i);
                            
                            
                            
                            if ([[arrayByDate objectAtIndex:a] isEqualToString:[tempTotalArray objectAtIndex:i]] && [[arrayByDate objectAtIndex:a + 3] isEqualToString:[tempTotalArray objectAtIndex:i + 2]])
                            {
                                doesExist = YES;
                                
                                // Update array; Add value to total; 
                                [arrayByDate replaceObjectAtIndex:a + 1 withObject:[NSString stringWithFormat:@"%i",[[arrayByDate objectAtIndex:a + 1] intValue] + [[tempTotalArray objectAtIndex:i + 1] intValue]]];
                                // +1 to value count
                                [arrayByDate replaceObjectAtIndex:a + 2 withObject:[NSString stringWithFormat:@"%i",[[arrayByDate objectAtIndex:a + 2] intValue] + 1]];
                                
                            }
                        }
                        
                        if (!doesExist) 
                        {
                            // Add to array
                            [arrayByDate addObject:[tempTotalArray objectAtIndex:i]];
                            [arrayByDate addObject:[tempTotalArray objectAtIndex:i + 1]];
                            [arrayByDate addObject:@"1"];
                            [arrayByDate addObject:[NSString stringWithFormat:@"%@",nn]];
                        }
                    }

                }    
                
			}			
		}
	}
	
    NSLog(@"arrayByDate:%@",arrayByDate);
    
    int averageValue = 0;
    
    // Average and add to valueArray
    for (int i = 1; i < [arrayByDate count]; i+=4) 
    {
        
        // valueTotal
        averageValue = [[arrayByDate objectAtIndex:i + 1] intValue] / [[arrayByDate objectAtIndex:i + 2] intValue];
        
        [valueArray addObject:[arrayByDate objectAtIndex:i]];
        [valueArray addObject:[NSString stringWithFormat:@"%i",averageValue]];
        [valueArray addObject:[arrayByDate objectAtIndex:i + 3]];
    }
    
	[yearDescriptor release];
	[monthDescriptor release];
	[dayDescriptor release];
	[groupTitleDescriptor release];
	[sortDescriptors release];
	[fetchRequest release];
    [arrayByDate release];
    
    
    NSLog(@"valueArray:%@",valueArray);
    
	return valueArray;
}



- (void) dealloc {
	[cal release];
	[super dealloc];
}

-(void)toggleSeriesType {
    stepLineMode = !stepLineMode;
}

#pragma mark -
#pragma mark Datasource Protocol Functions

// Returns the number of points for a specific series in the specified chart
- (int)sChart:(ShinobiChart *)chart numberOfDataPointsForSeriesAtIndex:(int)seriesIndex {
    //In our example, all series have the same number of points
    int numPoints = 0;
    if (seriesIndex == 0) 
    {
        numPoints = [series1Data count];
    }
    
    return numPoints;
}

// Returns the series at the specified index for a given chart
-(SChartSeries *)sChart:(ShinobiChart *)chart seriesAtIndex:(int)index {
    
    NSLog(@"series: %i", index);
    
    // Our series are either of type SChartLineSeries or SChartStepLineSeries depending on stepLineMode.
    SChartLineSeries *lineSeries = stepLineMode? 
    [[[SChartStepLineSeries alloc] init] autorelease]:
    [[[SChartLineSeries alloc] init] autorelease];
    
    if (index == 1)
    {
        lineSeries.style.lineWidth = [NSNumber numberWithInt: 2];
        
        lineSeries.style.lineColor = [UIColor colorWithRed:151.f/255.f green:80.f/255.f blue:0.f alpha:1.f];
        lineSeries.style.areaColor = [UIColor colorWithRed:131.f/255.f green:90.f/255.f blue:10.f/255.f alpha:1.f];
        
        lineSeries.style.lineColorBelowBaseline = [UIColor colorWithRed:227.f/255.f green:182.f/255.f blue:0.f alpha:1.f];
        lineSeries.style.areaColorBelowBaseline = [UIColor colorWithRed:150.f/255.f green:120.f/255.f blue:0.f alpha:1.f];
        
        lineSeries.baseline = [NSNumber numberWithInt:0];
        lineSeries.style.showFill = YES;
        
        lineSeries.crosshairEnabled = YES;  
    }
    else 
    {
        lineSeries.style.lineWidth = [NSNumber numberWithInt: 2];
        
        lineSeries.style.lineColor = [UIColor colorWithRed:80.f/255.f green:151.f/255.f blue:0.f alpha:1.f];
        lineSeries.style.areaColor = [UIColor colorWithRed:90.f/255.f green:131.f/255.f blue:10.f/255.f alpha:1.f];
        
        lineSeries.style.lineColorBelowBaseline = [UIColor colorWithRed:227.f/255.f green:182.f/255.f blue:0.f alpha:1.f];
        lineSeries.style.areaColorBelowBaseline = [UIColor colorWithRed:150.f/255.f green:120.f/255.f blue:0.f alpha:1.f];
        
        lineSeries.baseline = [NSNumber numberWithInt:0];
        lineSeries.style.showFill = YES;
        
        lineSeries.crosshairEnabled = YES;
    }
    
    return lineSeries;
}

// Returns the number of series in the specified chart
- (int)numberOfSeriesInSChart:(ShinobiChart *)chart {
    return 1;
}

// Returns the data point at the specified index for the given series/chart.
- (id<SChartData>)sChart:(ShinobiChart *)chart dataPointAtIndex:(int)dataIndex forSeriesAtIndex:(int)seriesIndex {
    
    // Construct a data point to return
    SChartDataPoint *datapoint = [[[SChartDataPoint alloc] init] autorelease];
    
    // For this example, we simply move one day forward for each dataIndex

    datapoint.xValue = [series1Dates objectAtIndex:dataIndex];
   // datapoint.xValue = [series2Dates objectAtIndex:dataIndex];
    
    // Construct an NSNumber for the yValue of the data point
    datapoint.yValue = [NSNumber numberWithFloat:[[series1Data objectAtIndex:dataIndex] floatValue]];
   // datapoint.yValue = [NSNumber numberWithFloat:[[series2Data objectAtIndex:dataIndex] floatValue] - 10000.f];
    
    return datapoint;
}

@end
